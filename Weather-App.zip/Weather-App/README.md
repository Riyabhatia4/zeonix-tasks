## Weather App
### Built using React.js and openweathermap API
### live demo : [www.liveweather.com](https://liveweatherupdates.netlify.app/)
### screenshots:


<table>
  <tr>
    <td width="30%">Mobile view<img src="https://github.com/arjuncvinod/Weather-App/assets/68469520/1bae88a3-4559-49bd-95b1-b5c69bd72a73"></td>
    <td>Desktop View<img src="https://github.com/arjuncvinod/Weather-App/assets/68469520/1c5ba0c6-ecf8-4305-86fc-745e480b03a8"></td>
  </tr>
</table>

